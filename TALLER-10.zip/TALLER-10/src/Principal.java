import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Scanner;

//TALLER REALIZADO POR ANDRES HENAO Y OSCAR SALAMANCA
public class Principal {

	public static void main(String[] args) {
		
		String nombre, residencia, cedula, raza;
		int edad;
		float peso;
		boolean bandera;
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		Calendar fechaNacimiento = Calendar.getInstance();
		Persona dueno;

		Scanner leer = new Scanner(System.in);
		CentroAdopcion centro = new CentroAdopcion("Centro"); // Instancia de centro de adopcion
		
		int opcion = 0;
		
		while (opcion != 5) {
			System.out.println("Bienvenido al centro de adopcion, que desea hacer?");
			System.out.println("1. Rescatar un perro");
			System.out.println("2. Adoptar un perro");
			System.out.println("3. Cambiarle el nombre a su mascota");
			System.out.println("4. Revisar base de datos");
			System.out.println("5. Salir");
			
			opcion = leer.nextInt();
			
			switch (opcion) {
				
				case 1:
					//Pedir los datos del perro
					System.out.println("Ingrese los datos del perro ");
					leer.nextLine();
					System.out.print("Nombre: ");
					nombre = leer.nextLine();
					System.out.print("Raza: ");
					raza = leer.nextLine();
					System.out.print("Peso: ");
					peso = leer.nextFloat();
					//Pedir la fecha de nacimiento del perro
					bandera = true;
					while(bandera) {
				        System.out.println("Ingrese la fecha de nacimiento con el formato: dd/mm/yyyy");
				        try {
				            String fecha = leer.nextLine();
				            fechaNacimiento.setTime(df.parse(fecha));
				            bandera = false;
				        } catch (ParseException e) {
				            e.printStackTrace();
				            System.out.println("Fecha inválida. Por favor, intente de nuevo.");
				        }
				    }
					
					//Se crea un nuevo perro usando el constructor y se llama a la funcion rescatarMascota con ese perro
					Perro nuevoPerro = new Perro(nombre, raza, peso, fechaNacimiento);
					centro.rescatarMascota(nuevoPerro);
					break;
				case 2:
					Persona cliente;
					System.out.print("Ingrese su cedula: ");
					cedula = leer.nextLine();
					leer.next();
					//Condicionales, si el cliente ya existe se le asigna a la variable cliente, 
					//sino se crea un nuevo cliente con el constructor y se asigna a la variable
					if (centro.buscarCliente(cedula) != null) {
						System.out.println("El cliente es: " + centro.buscarCliente(cedula).getNombre()); // se muestra el cliente llamando la funcion
						cliente = centro.buscarCliente(cedula); //se asigna el cliente anterior a la variable cliente
					}
					else {
						System.out.println("El cliente no esta registrado, ingrese los datos");
						leer.nextLine();
						System.out.print("Nombre: ");
						nombre = leer.nextLine();
						System.out.print("Edad: ");
						edad = leer.nextInt();
						leer.nextLine();
						System.out.print("Residencia: ");
						residencia = leer.nextLine();
						cliente = new Persona(nombre, edad, residencia, cedula); //Se crea el cliente y se asigna a cliente
						centro.agregarCliente(cliente);
					}
					System.out.println("Lista de internos: ");
					centro.mostrarInternos(); // Imprime la lista de perros en el centro
					System.out.print("Escriba el nombre del perro que quiere adoptar: ");
					String seleccionPerro; // Variable para elegir un perro 
					seleccionPerro = leer.nextLine();
					
					//Condicional que revisa si el perro esta disponible en la lista
					if(centro.buscarPerro(seleccionPerro) != null) {
						Perro perro = centro.buscarPerro(seleccionPerro); //Se recibe el perro que se encuentra en la lista
						centro.darEnAdopcion(perro, cliente); //Se da en adopcion el perro
						System.out.println("El perro fue adoptado!");
					}
					else {
						System.out.println("El perro no fue encontrado");
					}
					break;
				case 3:
					System.out.print("Ingrese su numero de cedula: ");
					cedula = leer.nextLine();
					leer.next();
					
					//Condicional para revisar si el usuario esta en la base de datos
					if(centro.buscarCliente(cedula) != null) {
						centro.buscarCliente(cedula).mostrarMascotas(); //Muestra las mascotas del cliente con la cedula ingresada
						System.out.print("A que perro desea cambiarle el nombre: ");
						String nombreAnterior = leer.nextLine();
						leer.next();
						//Condicion para revisar si el perro seleccionado esta en la lista de mascotas de la persona
						if(centro.buscarCliente(cedula).buscarMascota(nombreAnterior) != null) { 
							System.out.print("Que nombre desea ponerle?: ");
							String nombreNuevo = leer.nextLine();
							leer.next();
							centro.buscarCliente(cedula).cambiarNombreMascota(nombreAnterior, nombreNuevo);
						}
						else {
							System.out.println("El perro no fue encontrado en la lista");
						}
					}
					else {
						System.out.println("El usuario no esta en la base de datos");
					}
					break;
				case 4:
					centro.mostrarAdopciones(); //Se muestra la base de datos completa
					break;
				case 5:
					break;
				default:
					System.out.println("Opcion invalida");
					break;
			}
		}
	}


}
