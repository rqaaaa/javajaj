import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

public class Perro {
	
	private String nombre;
	private String raza;
	private float peso;
	private Calendar fechaNacimiento;
	private Calendar fechaAdopcion;
	private Persona dueno;
	
	//Constructor
	public Perro(String nombre, String raza, float peso, Calendar fechaNacimiento) {
		this.nombre = nombre;
		this.raza = raza;
		this.peso = peso;
		this.fechaNacimiento = fechaNacimiento;
	}
	
	//Setters y Getters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public String getFechaNacimientoStr() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return formatter.format(fechaNacimiento.getTime());

	}
	public Calendar getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Calendar fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public String getFechaAdopcionStr() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return formatter.format(fechaAdopcion.getTime());

	}
	public Calendar getFechaAdopcion() {
		return fechaAdopcion;
	}

	public void setFechaAdopcion(Calendar fechaAdopcion) {
		this.fechaAdopcion = fechaAdopcion;
	}

	public Persona getDueno() {
		return dueno;
	}

	public void setDueno(Persona dueno) {
		this.dueno = dueno;
	}
	
	//Metodos
	public int calcularEdad() {
		
		Calendar fecha = new GregorianCalendar(); // Fecha actual
		
		return fecha.get(Calendar.YEAR) - fechaNacimiento.get(Calendar.YEAR); //Se le resta al año actual el año de nacimiento

	}

	
	
	
}
