import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

public class Persona {
	private String nombre;
	private int edad;
	private String residencia;
	private String cedula;
	ArrayList<Perro> mascotas = new ArrayList<Perro>(); //Lista de mascotas que tiene la persona
	
	//Constructor
	public Persona(String nombre, int edad, String residencia, String cedula) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.residencia = residencia;
		this.cedula = cedula;
	}
	
	
	//Setters y Getters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getResidencia() {
		return residencia;
	}

	public void setResidencia(String residencia) {
		this.residencia = residencia;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public ArrayList<Perro> getMascotas() {
		return mascotas;
	}

	public void setMascotas(ArrayList<Perro> mascotas) {
		this.mascotas = mascotas;
	}


	//Metodos
	
	//Metodo para crear adoptar una mascota
	public void adoptarMascota(Perro perro) {
		Calendar fecha = new GregorianCalendar(); //Se genera una fecha (actual)
		mascotas.add(perro); //Se agrega a la lista de mascotas
		perro.setDueno(this); //Se pone el dueño al cliente acutal
		perro.setFechaAdopcion(fecha); //La fecha de adopcion termina siendo la actual
	}
	
	//Metodo para buscar una mascota
	public Perro buscarMascota(String nombre) {
		//For each con variable p de tipo Perro para comparar el nombre ingresado con el de los perros
		for(Perro p : mascotas) {
			if (p.getNombre().equals(nombre)) {
				return p;
			}
		}
		return null;
	}
	
	//Metodo para cambiarle el nombre a una mascota
	public void cambiarNombreMascota(String nombreAnterior, String nombreNuevo) {
			Perro perro = buscarMascota(nombreAnterior); //Se busca la mascota con el nombre anterior (actual) y se le asigna a perro
			if(perro != null) {
				perro.setNombre(nombreNuevo); //Al perro encontrado se le asigna el nuevo nombre
			}
		}
	
	//Metodo para mostrar todas las mascotas de una persona
	public void mostrarMascotas() {
		//For each con variable p de tipo Perro que itera por la lista mascotas e imprime sus atributos
		for(Perro p : mascotas) {
			System.out.println();
			System.out.println("Nombre: " + p.getNombre());
			System.out.println("Raza: " + p.getRaza());
			System.out.println("Peso: " + p.getPeso());
			System.out.println("Fecha de nacimiento: " + p.getFechaNacimientoStr());
			System.out.println("Fecha de adopcion: " + p.getFechaAdopcionStr());
			System.out.println();
		}
	}
	
	
}
