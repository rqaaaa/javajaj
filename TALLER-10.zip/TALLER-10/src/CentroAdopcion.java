import java.util.ArrayList;

public class CentroAdopcion {
	private String nombre;
	
	ArrayList<Perro> internos = new ArrayList<Perro>();
	ArrayList<Persona> clientes = new ArrayList<Persona>();
	

	
	public CentroAdopcion(String nombre) {
		this.nombre = nombre;
	}
	
	//Setters y Getters
	
	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public ArrayList<Perro> getInternos() {
		return internos;
	}



	public void setInternos(ArrayList<Perro> internos) {
		this.internos = internos;
	}



	public ArrayList<Persona> getClientes() {
		return clientes;
	}



	public void setClientes(ArrayList<Persona> clientes) {
		this.clientes = clientes;
	}


	
	//Metodos
	//Metodo para iterar por la lista de internos e imprimirlos
	public void mostrarInternos() {
		//For each con variable p de tipo Perro para iterar en la lista internos para imprimir sus atributos
		for(Perro p : internos) {
			if (p.calcularEdad() >= 1) {
				System.out.println();
				System.out.println("Nombre: " + p.getNombre());
				System.out.println("Raza: " + p.getRaza());
				System.out.println("Peso: " + p.getPeso());
				System.out.println("Fecha de nacimiento: " + p.getFechaNacimientoStr());
				System.out.println();
			}
		}
	}
	//Metodo para rescatar una mascota y agregarla a la lista de internos
	public void rescatarMascota(Perro perro) {
		internos.add(perro);
	}
	//Metodo para dar en adopcion un perro y quitarlo de la lista de internos
	public void darEnAdopcion(Perro seleccionPerro, Persona persona) {
		persona.adoptarMascota(seleccionPerro);
		internos.remove(seleccionPerro);
	}
	
	//Metodo para agregar una persona a la lista de clientes
	public void agregarCliente(Persona persona) {
		clientes.add(persona);
	}
	
	//Metodo buscar a un cliente en la base de datos
	public Persona buscarCliente(String cedula) {
		for (Persona p : clientes) {
			if (p.getCedula().equals(cedula)) {
				return p;
			}
		}
		return null;
	}
	//Metodo para rescatar una mascota y agregarla a la lista de internos
	public Perro buscarPerro(String nombre) {
		for (Perro p : internos) {
			if (p.getNombre().equals(nombre)) {
				return p;
			}
		}
		return null;
	}
	
	//Metodo para mostrar la lista de clientes con sus respectivas mascotas
	public void mostrarAdopciones() {
		//for each con variable de tipo persona que itera por la lista clientes, muestra el nombre del cliente y luego utiliza el metodo de mostrarMascotas()
		for (Persona p : clientes) {
			System.out.println("Nombre del cliente: " + p.getNombre());
			System.out.println("Lista de mascotas de " + p.getNombre() );
			p.mostrarMascotas();
		}
	}
	
}
